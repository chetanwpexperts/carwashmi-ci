<?php 
class Dashboard extends CI_Controller
{
	var $data;
    public function __construct(){
 		parent::__construct();	
		$this->load->model('User_model');
 	}

	public function index()
	{
		$data = array();
		$this->load->helper('url');
		$this->dashboard();
	}
	
	
	public function dashboard()
	{
		$session = $this->session->userdata;
		if($session['loginuser'] == '1'){
			$this->load->view('dashboard');
		}else{
			redirect('login');
		}
	}
	
	public function users()
	{
		$session = $this->session->userdata;
		if($session['loginuser'] == '1'){
			$this->load->view('users');
		}else{
			redirect('login');
		}
	}
	
	public function admin_profile()
	{
		$p = $this->User_model->profile();
		return $p;
	}
	
	public function profile()
	{
		$data['profile'] = $this->admin_profile();
		$session = $this->session->userdata;
		if($session['loginuser'] == '1'){
			$this->load->view('profile',$data);
		}else{
			redirect('login');
		}
	}
}
?>