<?php 
class Services extends CI_Controller
{
	var $data;
    public function __construct(){
 		parent::__construct(); 
		$this->load->model('Service_model'); 
 	}

	public function index()
	{
		$data = array();
		$this->load->helper('url');
		$this->services();
	}

	public function add_services()
	{
		$insert_user_in_database=array(
		   'service_name' => $this->input->post('service'),
		);		   
		$query=$this->db->insert('services',$insert_user_in_database);
		return $query;
	}
	
	public function get_services()
	{
		$arr = $this->Service_model->services();
		return $arr;
	}
	
	public function services()
	{
		$data['get_services'] = $this->get_services();
		$session = $this->session->userdata;
		if($session['loginuser'] == '1'){
			$this->load->view('services',$data);
		}else{
			redirect('login');
		}
	}
	
	function service_action(){
		$datavl = array();
		$action = $this->input->post('action');
		$id = $this->input->post('id');
		$service_name = $this->input->post('service_name');
		$datavl['service_name'] = $service_name;
		switch($action){
			case "edit":
				$result = $this->Service_model->edit($id);
				break;
			case "update":
				$result = $this->Service_model->update($datavl,$id);
				break;
			case "delete":
				$result = $this->Service_model->deletes($id);
				break;
		}
		
		echo $result;
		
	}
}
?>