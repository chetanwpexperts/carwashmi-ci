<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Web extends CI_Controller
{
    function __construct() 
	{
		parent::__construct();
		$this->load->model('Common_model');
		$this->load->model('Api_model');
		$this->load->model('Service_model');
		$this->load->library("braintree_lib");
	}
	
	public function index()
	{   
		header( 'Access-Control-Allow-Headers: Authorization, Content-Type' );
		header('content-type: application/json; charset=utf-8');
		header("Accept: application/json");
		header("access-control-allow-origin: *");
		error_reporting(E_ALL);
		$responseArr = array();
		$response = null;
		$message = null;
		$code = null;

		$myFile = FCPATH ."pwd.txt";
		$lines = file($myFile);
		$auth_variables = explode("|", $lines[0]);
		$actionn = $_POST;
		
		$data = array("username" => $auth_variables[0], "password" => $auth_variables[1]);
		if(@$actionn['username'] != "" && @$actionn['pwd'] != "") {
			$error = '';
			$username = $actionn['username'];
			$password = $actionn['pwd'];
			
			if($username == $data['username'] && $password == $data['password']){
				file_put_contents(FCPATH . 'array.txt', var_export($actionn, TRUE));
				switch($actionn['action']){					
					case 'login':
						$email = $actionn['email'];
						$pwd = $actionn['password'];
						$data = array('email' => $email,'password' => $pwd);
						if($this->Api_model->getuser($email) == true){
							$veryfi = $this->Api_model->email_verify($email);
							$arr = $this->Api_model->login($data);
							if($arr != 0){
								if($veryfi['is_email_verified'] == 0){
									$code = 301;
									$error = "Your email not verified!";
								}else{
									$responseArr['userinfo'] = $arr;
									$response = ($responseArr);
									$code = 200;
									$message = 'Login successful';
								}
							}else{
								$code = 300;
								$error = "Username and password doesn't match!";
							}
						}else{
							$error = 'User not found!';
							$code = 102;
						}
						break;	
					case 'signup':
						$random = substr(md5(uniqid(mt_rand(), true)), 0, 32);
						$data['random'] = $random;
						$data = array( 
							'email' => $actionn['email'], 
							'password' => md5($actionn['password']),
							'user_type' => $actionn['user_type'], 
							'registration_date' => date('y-m-d h:i:s')
						);
						if($this->Api_model->getuser($actionn['email'])==true){
							$error = 'User Already Exists';
							$code = 300;
						}else{
							$uid = $this->Api_model->register($data);
							$this->Api_model->updatetokan($random, $uid);
							$data['user_name'] = $this->Api_model->getusername($uid);
							$data['password'] = $actionn['password'];
							$data['link'] = base_url() . "web/confirm?hash=".$random."&is_verify=f&u=".$uid;
							$to = $actionn['email'];
							$subject = 'Registration Successfully Done.';
							$headers = "From: carwashmi@carwashmi.com\r\n"; 
							$headers .= "Reply-To: noreply@carwahsmi.com\r\n";
							$headers .= "MIME-Version: 1.0\r\n";
							$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
							ob_start();
								$this->load->view('success_email_template', $data);
							$message = ob_get_clean();
							$m = mail($to, $subject, $message, $headers);
							if($m){
								$response = ($uid);		
								$code = 200;
								$message = 'User registred successfully';
							}else{
								$error = 'We are unable to send Email!';		
								$code = 301;
							}							
						}
						break;
					case 'forgotpass':
						$email = $actionn['email'];
						if($this->Api_model->getuser($email)==true){
							$hash = substr(md5(uniqid(mt_rand(), true)), 0, 8); 
							$arr = $this->Api_model->forgotpassStatus(1,$email);
							$this->Api_model->update_forgot_firstlogin_status($email);
							$data['hash'] = $hash;
							$this->Api_model->updateTempPass($data['hash'],$email);
							$to = $email;
							$subject = 'Set up a new password for Carwashmi';

							$headers = "From: carwashmi@carwashme.com\r\n"; 
							$headers .= "Reply-To: noreply@carwashmi.com\r\n";
							$headers .= "MIME-Version: 1.0\r\n";
							$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
							ob_start();
								$this->load->view('reset_email_template', $data);
							$message = ob_get_clean();
							$m = mail($to, $subject, $message, $headers);
							if($m){
								$response = ($arr);
								$code = 200;
								$message = 'Email has been sent with temporary password. You can change it after login.';
							}else{
								$code = 101;
								$error = 'Please try again';
							}
						}else{
								$error = 'Email address not found';
								$code = 102;
						}
						break;
					case 'changepass':
						$new_password = md5($actionn['new_password']);
						$email = $actionn['email'];
						$oldpassword = $this->Api_model->checkOldpassword($email);
						if($new_password == $oldpassword){
							$code = 300;
							$error = 'New password must be diffrent from old password!';
						}else{
							
							if($this->Api_model->update_password($new_password,$email)){
								$this->Api_model->forgotpassStatus(0,$email);
								$this->Api_model->update_firstlogin_status($email);
								$code = 200;
								$message = 'Password changed successfully';
							}else{
								$code = 300;
								$error = 'Please try again'; 
							}
						}
						break;
					case 'getprofile':
						$udata = array();
						$arr = $this->Api_model->getprofile($actionn['user_id']);
						if(count($arr) > 0 && $arr != false){
							$udata['user_id'] = intval($arr->user_id);
							$udata['first_name'] = $arr->first_name;
							$udata['last_name'] = $arr->last_name;
							$udata['email'] = $arr->email;
							$udata['mobile_number'] = $arr->mobile_number;
							$udata['location'] = $arr->location;
							$udata['user_type'] = $arr->user_type;
							$udata['latitude'] = $arr->latitude;
							$udata['longitude'] = $arr->longitude;
							$udata['rider_type']=$arr->rider_type;
                                                        $udata['dob']=$arr->dob;
							$udata['is_elite_service'] = ($arr->is_elite_service) ? true : false;
							$udata['is_standard_service'] = ($arr->is_standard_service) ? true : false;
							$udata['is_premium_service'] = ($arr->is_premium_service) ? true : false;
							
							$udata['points'] = $arr->points;
							$udata['firstlogin'] = $arr->firstlogin;
							
							$response = ($udata);		
							$code = 200;
							$message = '';
						}else{
							$code = 300;
							$error = 'Record Not found!'; 
						}
						break;
					case 'updateprofile':
						$udata = array();
						$arr = $this->Api_model->getprofile($actionn['user_id']);
						$udata['user_id'] = isset($actionn['user_id'])?$actionn['user_id']:0;
						$udata['first_name'] = (isset($actionn['first_name']))?$actionn['first_name']:$arr->first_name;
						$udata['last_name'] = (isset($actionn['last_name']))?$actionn['last_name']:$arr->last_name;
						$udata['mobile_number'] = (isset($actionn['mobile_number']))?$actionn['mobile_number']:$arr->mobile_number;
						$udata['location'] = (isset($actionn['location']))?$actionn['location']:$arr->location;
						$udata['latitude'] = (isset($actionn['latitude']))?$actionn['latitude']:$arr->latitude;
						$udata['longitude'] = (isset($actionn['longitude']))?$actionn['longitude']:$arr->longitude;
						$udata['rider_type'] = (isset($actionn['rider_type']))?$actionn['rider_type']:"";
						$udata['user_type'] = (isset($actionn['user_type']))?$actionn['user_type']:$arr->user_type;
						$udata['firstlogin'] = 1;
						
						$udata['is_elite_service'] = ($actionn['is_elite_service'] == "true")?1:0;
						$udata['is_standard_service'] = ($actionn['is_standard_service'] == "true")?1:0;
						$udata['is_premium_service'] = ($actionn['is_premium_service'] == "true")?1:0;
						$udata['dob'] = (isset($actionn['dob']))?$actionn['dob']:$arr->dob;
						
						$arr1 = $this->Api_model->updateuser($udata,$actionn['user_id']);
						
						$arr = array('Update Profile' => true);
						$response = ($arr);	
						$code = 200;
						$message = 'Profile Updated successfully';

						break;
					case 'profileimage':
						$postData = array();
						$path = FCPATH ."assets/images/users/profile/".$actionn['user_id']."_profile.png";
						$data = $actionn['img'];
						$postData['user_id'] = $actionn['user_id'];
						$postData['img_path'] = base_url()."assets/images/users/profile/".$actionn['user_id']."_profile.png";
						$img = str_replace('data:image/png;base64,', '', $postData['img_path']);
						$img = str_replace(' ', '+', $img);
						$data = base64_decode($img);
						$result = file_put_contents($path, $data);
						if($result == true){
							$arr = $this->Api_model->update_profile_img($postData);
							if($arr == 1){
								$response = (array('insert'=>$path));	
								$code = 200;
								$message = 'Profile Image added successfully';								
							}else{
								$response = (array('update'=>$path));	
								$code = 200;
								$message = 'Profile Image Updated successfully';
							}
						}else{
							$error = 'Profile image not updated!';		
							$code = 300;
						}
						break;
					case 'getprofileimg':
						$arr = $this->Api_model->checkprofileimage($actionn['user_id']);
						$img = ($arr != false)?$arr:false;
						$response = ($img);	
						$code = 200;
						$message = 'success';								
						break;
					case 'savelatlong': 
						$data = array( 
							'email' => $actionn['email'], 
							'latitude' => $actionn['latitude'], 
							'longitude' => $actionn['longitude'],
						);
						
						if($this->Api_model->getuser($actionn['email'])==true){
							$arr = $this->Api_model->update_user_location($data,$actionn['email']);
							$response = ($arr);		
							$code = 200;
							$message = 'Location Saved Successfully';							
						}else{
							$error = 'Email Not Exists!';		
							$code = 300;
						}
						break;
					case 'getwashers':
						$finalwashers = array();
						$lat = $actionn['latitude'];
						$long = $actionn['longitude'];
						$arr = $this->Api_model->getAllwashers();
						if($arr > 0){
							for($count=0;$count<count($arr);$count++){
								if($arr[$count]->rider_type == 0){
									$bikers_distense = $this->Api_model->distance($lat, $long, $arr[$count]->latitude, $arr[$count]->longitude);
									if($bikers_distense <= 40){
										array_push($finalwashers,$arr[$count]);
									}
								}else{
									$d = $this->Api_model->distance($lat, $long, $arr[$count]->latitude, $arr[$count]->longitude);
									if($d <= 40){
										array_push($finalwashers,$arr[$count]);
									}
								}
							}
							if($finalwashers > 0){
								$response = ($finalwashers);		
								$code = 200;
								$message = 'success';
							}else{
								$code = 301;
								$error = 'No service provider found!';
							}
						}else{
							$code = 300;
							$error = 'No record found!';
						}
						break;
					case "request":
						$washers = array();
						$points = $actionn['points'];
						$vehicle_type = intval($actionn['vehicle_type']);
						$service_type = intval($actionn['service_type']);
						$requestData = array(
							'user_id' => $actionn['user_id'], 
							'vehicle_type' => $vehicle_type,
							'service_type' => $service_type,
							'points' => $points
						);
						
						$requestId = $this->Api_model->request($requestData, $actionn['user_id'],$points);
						if($requestId){
							$uaData = array(
								'user_id' => $actionn['user_id'], 
								'transaction_type' => 1,
								'is_transaction_settled' => 0,
								'client_request_id' => $requestId,
								'points' => $points
							);
							$this->Api_model->useraccountdata($uaData, $requestId);
							if(count($actionn['users']) > 0){
								for($w=0;$w<count($actionn['users']);$w++){
									$responseData = array(
										'client_request_id' => $requestId, 
										'user_id' => $actionn['users'][$w]['user_id']
									);
									$responseId = $this->Api_model->add_response($responseData);
									$username = $this->Api_model->getusername($responseData['user_id']);
									$tokan = $this->Api_model->sdschecktokan($responseData['user_id']);
									$this->Api_model->sendnotification($tokan, $username." - New job created for you");
								}
							}
							if($actionn['users'] > 0){
								$response = (count($actionn['users']));		
								$code = 200;
								$message = 'success';
							}else{
								$code = 301;
								$error = 'No service provider found!';
							}
							
						}
						break;
					case "response":
						$arr = $this->Api_model->getresponse();
						$requestCount = count($arr);
						if($arr > 0){
							$response = array('count' => $requestCount);		
							$code = 200;
							$message = 'success';
						}else{
							$code = 300;
							$error = 'No response found!';
						}
						break;
					case "totalwash":
						$ar = array();
						$requests = $this->Api_model->getwashcount($actionn['user_id']);
						if($requests != false){
							foreach($requests as $r){
								if($r->rider_type == 0){
									$ar['total_bike_wash'] = count($requests->rider_type);
								}else{
									$ar['total_car_wash'] = count($requests->rider_type);
								}
							}
							
							$ar['total'] = ($ar['total_bike_wash'] + $ar['total_car_wash']);
							
							$response = ($ar);		
							$code = 200;
							$message = 'success';
						}else{
							$ar['total_bike_wash'] = 0;
							$ar['total_car_wash'] = 0;
							$ar['total'] = 0;
							$response = ($ar);
							$code = 300;
							$message = 'empty';
						}
						break;
					case 'addpaymentmethod':
						if(isset($actionn['user_id'])){
							$cardnumber = isset($actionn['cardnumber']) ? $actionn['cardnumber'] : "";
							$type = $this->Api_model->validatecard($cardnumber);
							switch($type){
								case "visa" :
									$paymenttype = "visa";
									break;
								case "mastercard" :
									$paymenttype = "mastercard";
									break;
								case "amex" :
									$paymenttype = "amex";
									break;
								case "discover" :
									$paymenttype = "discover";
									break;
								case "unknown" :
									$paymenttype = "unknown";
									break;
							}
							
							if($paymenttype == "unknown"){
								$code = 300;
								$error = 'Cardnumber not valid!';
							}else{
								
								$month = isset($actionn['xpirymonth']) ? $actionn['xpirymonth'] : "";
								$year = isset($actionn['year']) ? $actionn['year'] : "";
								$respo = $this->Api_model->is_valid_expiration ( $month, $year );
								if($respo == -2){
									$code = 301;
									$error = 'Card expiry not valid!';
									exit;
								}
								
								$cvv = isset($actionn['cvv']) ? $actionn['cvv'] : "";
								$xpiry = $month.'/'.$year;
								$country = isset($actionn['country']) ? $actionn['country'] : "";
							
								$sql1 = "INSERT INTO payment_settigns(user_id,card_type,card_number,expiry_year,expiry_month,country,card_name) VALUES('".$actionn['user_id']."','".$paymenttype."','".$cardnumber."','".$year."','".$month."','".$country."','".$actionn['card_name']."')";
								$rw2 = $conn->query($sql1);
								if($rw2){
									$response = array('paymentmethod' => true);		
									$code = 200;
									$message = 'success';
								}else{
									$code = 300;
									$error = 'Card details not valid!';
								}
							}
						}
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
					case 'cardpayment':
						$paymentData = array();
						$paymentStatus = "";
						$price = $actionn['amount'];
						$userid = $actionn['user_id'];
						$carddata = $this->Api_model->getuserCardDetails($userid);
						$paymentData['amount'] = $price;
						$card_number=str_replace("+","",$carddata->card_number);  
						$card_holder_name=$carddata->card_name;
						$expiry_month=$carddata->expiry_month;
						$expiry_year=$carddata->expiry_year; 
						$cvv=$carddata->cvv;
						$expirationDate=$expiry_month.'/'.$expiry_year;

						/* Braintree_Configuration::environment('production');*/
						Braintree_Configuration::environment('sandbox');
						Braintree_Configuration::merchantId('wd349dtjw63mbzm5');
						Braintree_Configuration::publicKey('fqt336fb4fcjprkh');
						Braintree_Configuration::privateKey('2442c7b60f4642dcdb0bd3c14ed4fd49'); 

						$result = Braintree_Transaction::sale(array(
							'amount' => $price,
							'creditCard' => array(
								'number' => $card_number,
								'cardholderName' => $card_name,
								'expirationDate' => $expirationDate,
								'cvv' => $cvv
							)
						));
						if ($result->success == true) 
						{
							$paymentStatus = 1;
						}else{
							$paymentStatus = 2;
						}
						
						if ($result->success == true) 
						{
							if($result->transaction->id)
							{
								$paymentData['transaction_id'] = $result->transaction->id;
								if($result->transaction->creditCard['cardType'] == "MasterCard"){
									$type = 0;
								}
								if($result->transaction->creditCard['cardType'] == "Visa"){
									$type = 0;
								}
								if($result->transaction->creditCard['cardType'] == "Amex"){
									$type = 0;
								}
								if($result->transaction->creditCard['cardType'] == "Discover"){
									$type = 0;
								}
								$paymentData['payment_type'] = $type;
								$paymentData['user_id'] = $actionn['user_id'];
								$paymentData['washer_response_id'] = $actionn['washer_response_id'];
								$paymentData['client_request_id'] = $actionn['client_request_id'];
								$paymentData['payment_status'] = $paymentStatus;
								$this->Api_model->addorder($paymentData);
								$this->Api_model->updatePaymentResponse($actionn['client_request_id'], 	1);
								$response = ($result);		
								$code = 200;
								$message = 'success'; 
							}
						}
						else 
						{
							$paymentData['user_id'] = $actionn['user_id'];
							$paymentData['washer_response_id'] = $actionn['washer_response_id'];
							$paymentData['client_request_id'] = $actionn['client_request_id'];
							$paymentData['payment_status'] = $paymentStatus;
							$this->Api_model->addorder($paymentData);
							$this->Api_model->updatePaymentResponse($actionn['client_request_id'], 	0);
							$response = ($result);		
							$code = 300;
							$error = 'error'; 
						}
						break;
					case "washernotification":
						$notifications = $this->Api_model->getwasherNotification($actionn['user_id']);
						if(count($notifications)>0){
							$response = ($notifications);		
							$code = 200;
							$message = 'success';
						}else{
							$code = 300;
							$error = 'Zero notification!';
						}
						break;
					case "washerhistory":
						$notifications = $this->Api_model->washerhistory($actionn['user_id']);
						if(count($notifications)>0){
							$response = ($notifications);		
							$code = 200;
							$message = 'success';
						}else{
							$code = 300;
							$error = 'Zero notification!';
						}
						break;
					case "updatewasherresponse":
						if($actionn['is_washer_accepted'] == 1){
							$this->Api_model->updateclientpaymentstatus($actionn['client_request_id'], 1); 
							$d = $this->Api_model->checkresponse($actionn['client_request_id']);
							$clientid = $this->Api_model->getclientID($actionn['client_request_id']);
							$washerid = $this->Api_model->getwasherID($actionn['washer_response_id']);
							$username = $this->Api_model->getusername($washerid);
							$tokan = $this->Api_model->sdschecktokan($clientid);
							$this->Api_model->sendnotification($tokan, "Job has been accepted by washer named ". $username);
							if(count($d) > 0){
								if($d[0]->is_request_open == 0){
									$this->Api_model->updateWresponse($actionn['washer_response_id'], 1);
									$this->Api_model->requestClose($actionn['client_request_id'], 1);
									$this->Api_model->allrequestclose($actionn['client_request_id'], $actionn['user_id']);
									$arr = $this->Api_model->getallwashersclosed();
									foreach($arr as $washers){
										$tokan = $this->Api_model->sdschecktokan($washers->user_id);
										$this->Api_model->sendnotification($tokan, "Job has been closed! Accepted by someone else!");
									}
									$code = 200;
									$message = 'success';
								}else{
									$requestClose = $this->Api_model->updateWresponse($actionn['washer_response_id'], 3);
									$response = ($requestClose);		
									$code = 301;
									$message = 'May reuqest has been closed or hired some one else!';
								}
							}else{		
								$code = 300;
								$error = 'No request found!';
							}
						}else{
							$update = $this->Api_model->updateWresponse($actionn['washer_response_id'], 2);
							$response = ($update);		
							$code = 200;
							$message = 'Success!';
						}
						break;
					case "getclientrequest":
						$arr = $this->Api_model->getclientrequest($actionn['client_request_id']);
						if(count($arr) > 0){
							$response = ($arr);		
							$code = 200;
							$message = 'success';
						}else{
							$code = 300;
							$error = 'No request found!';
						}
						break;
					case "allclientrequest":
						$arr = $this->Api_model->getallrequests($actionn['user_id']);
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
						
					case "clientrequestdetail":
						$arr = $this->Api_model->clientrequestdetail($actionn['client_request_id']);
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
					case "getservices":
						$arr = $this->Service_model->services();
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
					case "addpoints":
						$pointsArr = array( 
							'user_id' => $actionn['user_id'],
							'points' => $actionn['points'], 
							'transaction_id' => $actionn['transaction_id'],
							'environment' => $actionn['environment'], 
							'transaction_status' => $actionn['transaction_status']
						);
						$arr = $this->Api_model->addpoints($pointsArr,$actionn['user_id'],$actionn['points']);
						if($arr == false){
							$code = 300;
							$error = 'Access Denied!';
						}else{
							$response = true;		
							$code = 200;
							$message = 'success';
						}
						break;
					case "getpointslist":
						$arr = $this->Api_model->getpoints();
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
					case "getpoints":
						$arr = $this->Api_model->getpointsbyUid($actionn['user_id']);
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
					case 'updatelocation': 
						$data = array( 
							'latitude' => $actionn['latitude'], 
							'longitude' => $actionn['longitude'],
						);
						$arr = $this->Api_model->update_location($data,$actionn['user_id']);
						$response = ($arr);		
						$code = 200;
						$message = 'Location Updated Successfully';							
						break;
					case 'sendpushnotification':
						$message = $actionn['message']; 
						$id = $actionn['tokan'];
						
						$path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
		
						// $fields = array(
							// 'to' => $id,
							// 'notification' => array('title' => 'Working Good', 'body' => 'That is all we want'),
							// 'data' => array('message' => $message)
						// );
						
						$fields = array (
								'registration_ids' => array (
										$id
								),
								'data' => array (
										"message" => $message
								)
						);
				 
						$headers = array(
							'Authorization:key=AAAAQ0UQ8OA:APA91bFIv5LpTOyjisjDi5v-kZjkPaG414KOOzbfNfYxyu4VWl_implhePuHHQXNwxuhmhJXKVoaTv6rrNH-MLkO8pgharNRo9-M344E8_v80GrPwWhpWKVEuiMSGp8ETQ6sJYcDprJw',
							'Content-Type:application/json'
						);		
						$ch = curl_init();
				 
						curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 ); 
						curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
					
						$result = curl_exec($ch);
					   
						curl_close($ch);
						
						$response = array($result);		
						$code = 200;
						break;
					case 'getLocationHistory':
						$arr = $this->Api_model->getlocationhistory($actionn['user_id']);
						$response = ($arr);		
						$code = 200;
						$message = 'success';
						break;
					case 'saveLocationHistory':
						$locationData = array( 
							'user_id' => $actionn['user_id'],
							'latitude' => $actionn['latitude'], 
							'longitude' => $actionn['longitude']
						);
						$arr = $this->Api_model->addlocationhistory($locationData, $actionn['user_id']);
						if($arr == true){
							$response = true;		
							$code = 200;
							$message = 'success';
						}else{
							$response = false;		
							$code = 300;
							$error = 'error';
						}
						break;
					case 'updatedevicetokan':
						$uid = $actionn['user_id'];
						$data = array(
							'device_type' => $actionn['device_type'],
							'device_token' => $actionn['device_token']
						);
						$arr = $this->Api_model->updatedevicetokan($data, $uid);
						if($arr == true){
							$response = true;		
							$code = 200;
							$message = 'success';
						}else{
							$error = false;		
							$code = 300;
						}
						break;
					case 'checktokan':
						$uid = $actionn['user_id'];
						$arr = $this->Api_model->getallwashersclosed();
						if(count($arr) > 0){
							$response = $arr;		
							$code = 200;
							$message = 'success';
						}else{
							$error = false;		
							$code = 300;
						}
						break;
					case 'cancelrequest':
						$client_request_id = $actionn['client_request_id'];
						$arr = $this->Api_model->cancel($client_request_id);
						
						$response = "Success";		
						$code = 200;
						$message = 'success';
						
						break;
					case 'isjobcompleted':
						$client_request_id = $actionn['client_request_id'];
						$user_id = $actionn['user_id'];
						$arr = $this->Api_model->jobstatus($client_request_id,$user_id);
						
						$response = "Success";		
						$code = 200;
						$message = 'success';
						
						break;
					case 'userdetails':
						$userID = $actionn['user_id'];
						$arr = $this->Api_model->getuserData($userID);
						if(count($arr) > 0){
							$response = array($arr);	
							$code = 200;
							$message = 'success';
						}else{
							$error = false;		
							$code = 300;
						}
						break;
					case 'getuseraccounts':
						$userID = $actionn['user_id'];
						$arr = $this->Api_model->getDatawashmi($userID);
						if(count($arr) > 0){
							$response = array($arr);	
							$code = 200;
							$message = 'success'; 
						}else{
							$error = false;		
							$code = 300;
						}
						break;
					case 'userauthorization':
						$clientId = 'AS9dMfioMYwVvf0CulEfSnKWV9S5_nuKghEcMwuHJefx2sTjLa_BfiOufjR8nwIKkpaaAZUN00MVNfp0';
						$secret = 'EBZ7o5falKVKdKAh7N2soIykWDIaDvHvincQVsCpertHfTWngGLYOGaWVZ5PByi58j1dtgUhgxXKKg7D';
						$ch = curl_init('https://api.sandbox.paypal.com/v1/oauth2/token');
						curl_setopt($ch, CURLOPT_HTTPHEADER, 
						"Content-Type: application/x-www-form-urlencoded");
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_USERPWD, $clientId.":".$secret);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=authorization_code&response_type=token&redirect_uri=urn:ietf:wg:oauth:2.0:oob&code=".$actionn['code']);
						$response = curl_exec($ch);
						curl_close($ch);
						$json = json_decode($response);
						$data = array(
							'user_id' => $actionn['user_id'],
							'access_token' => $json->access_token,
							'refresh_token' => $json->refresh_token
						);
						try {
							$this->Api_model->saveauthorization($data);
						}
						catch (PDOException $e) {
							$message = 'Authentication Failed';
							$code = 301;
							$error = true;
						}
						catch (Exception $e) {
							$message = 'Authentication Failed';
							$code = 301;
							$error = true;
						}
						
						$message = 'Authentication Successful';
						$code = 200;
						$response = ($json);
						$error = false;
						break;
					case 'makepayment':
						$amount = $actionn['amount'];
						$tokendata = $this->Api_model->getusertokens($actionn['user_id']);
						$clientId = 'AS9dMfioMYwVvf0CulEfSnKWV9S5_nuKghEcMwuHJefx2sTjLa_BfiOufjR8nwIKkpaaAZUN00MVNfp0';
						$secret = 'EBZ7o5falKVKdKAh7N2soIykWDIaDvHvincQVsCpertHfTWngGLYOGaWVZ5PByi58j1dtgUhgxXKKg7D';
						$refreshToken = $tokendata->refresh_tokan;


						$ch = curl_init('https://api.sandbox.paypal.com/v1/oauth2/token');
						curl_setopt($ch, CURLOPT_HTTPHEADER, 
						array("Content-Type: application/x-www-form-urlencoded"));
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_USERPWD, $clientId.":".$secret);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=refresh_token&refresh_token='.$refreshToken);
						$response = curl_exec($ch);
						curl_close($ch);
						$json1 = json_decode($response);
					  
					   // echo '----'.$json1->access_token.'------------'.$_POST['id'];
						$ch = curl_init('https://api.sandbox.paypal.com/v1/payments/payment');
						curl_setopt($ch, CURLOPT_HTTPHEADER, 
						array("Content-Type: application/json", 
						"PayPal-Client-Metadata-Id: ".$actionn['id'],
					   // "PayPal-Client-Metadata-Id: ".$_POST['id'],
						"Authorization: Bearer ". $json1->access_token));

						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_USERPWD, $clientId.":".$secret);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_POSTFIELDS, '{
						   "intent":"sale",
						   "payer":{
							  "payment_method":"paypal"
						   },
						   "transactions":[
							  {
								 "amount":{
										"currency":"USD",
										"total":"'.$amount.'"
									 },
									 "description":"future of sauces"
								  }
							   ]
							}'
						);
						$response1 = curl_exec($ch);
						curl_close($ch);
						$json = json_decode($response1);
					   
						if($json->state=='approved'){
							$error = false;
							$message = 'Payment Successful!'.$json->state;
							$code = 301;
						}else{
							$error = true;
							$message = 'Payment Failed!'.$json->state;
							$code = 302;
						}
						$response = ($json);
						break;
				}
				$arr = array('success'=> $message, 'code'=> $code, 'response'=> $response, 'error'=> $error);
				$response = json_encode($arr);
				echo $response;				
				die;
			}else{
				$message = "Access Denied To Use Api!";
				$arr = array('error'=> array('errorcode' => 404, 'reason' => $message) );
				$response = json_encode($arr);
				echo $response;
			}
		}else{
			$message = "Access denied please check credentials used";
			$arr = array('error'=> array('errorcode' => 401, 'reason' => $message) );
			$response = json_encode($arr);
			echo $response;
		}
	}
	
	function confirm(){
		$data['getparam'] = $_REQUEST;
		$this->load->view('confirm',$data);
	}
}	