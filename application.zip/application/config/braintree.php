<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['braintree_merchant_id'] = 'wd349dtjw63mbzm5';
$config['braintree_public_key'] = 'fqt336fb4fcjprkh';
$config['braintree_private_key'] = '2442c7b60f4642dcdb0bd3c14ed4fd49';
$config['braintree_environment'] = 'sandbox';