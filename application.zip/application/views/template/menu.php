<nav>
	<ul>
		<li><a href="<?php echo base_url();?>dashboard"><span class="icon-laptop-phone"></span> Dashboard</a></li>
		<li><a href="<?php echo base_url();?>dashboard/users"><span class="icon-group-work"></span> Users</a></li>
		<li><a href="<?php echo base_url();?>services"><span class="icon-shield-check"></span> Services</a></li>
		<li><a href="<?php echo base_url();?>emails"><span class="fa fa-envelope"></span> Emails</a></li>
		<li><a href="<?php echo base_url();?>payment"><span class="fa fa-credit-card"></span> Payments</a></li>
		<li><a href="<?php echo base_url();?>requests"><span class="fa fa-taxi"></span> Requests</a></li>
		<!--- <li><a href="<?php // echo base_url();?>orders"><span class="fa fa-paper-plane-o"></span> Orders</a></li>--->
	</ul>
</nav>