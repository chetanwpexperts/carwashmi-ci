<!DOCTYPE html>
<html lang="en">
    <head>                        
        <title>Car Wash App - Admin Pannel</title>            
        
        <!-- META SECTION -->
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="shortcut icon" href="favicon.ico" type="<?php echo base_url();?>image/x-icon">
        <link rel="icon" href="favicon.ico" type="<?php echo base_url();?>image/x-icon">
        <!-- END META SECTION -->
        <!-- CSS INCLUDE -->        
        <link rel="stylesheet" href="<?php echo base_url();?>css/styles.css">
        <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url();?>css/profile.css">
        <!-- EOF CSS INCLUDE -->
    </head>
    <body>