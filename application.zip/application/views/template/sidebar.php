<div class="app">           

            <!-- START APP CONTAINER -->
            <div class="app-container">
                <!-- START SIDEBAR -->
                <div class="app-sidebar app-navigation app-navigation-style-default app-navigation-open-hover dir-left" data-type="close-other">
                    <a href="<?php echo base_url();?>" class="app-navigation-logo">
                        Car-Wash - Admin Template  
                    </a>
                    <?php include'menu.php'; ?>
                </div>
                <!-- END SIDEBAR -->