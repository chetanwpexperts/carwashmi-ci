<?php 
include'template/header.php';
// echo "<pre>";
// print_r($this->User_model->users());
// echo "</pre>";
$users = $this->User_model->users();
?>
<!-- APP WRAPPER -->
		 <?php include'template/sidebar.php'; ?>
       
                <!-- START APP CONTENT -->

                <div class="app-content">

                    <!-- START APP HEADER -->

                   <?php include'template/righ-header.php'; ?>

                    <!-- END APP HEADER  -->

                    

                    <!-- START PAGE HEADING -->

                    <div class="app-heading app-heading-bordered app-heading-page">

                        <div class="icon icon-lg">

                            <span class="icon-group-work"></span>

                        </div>

                        <div class="title">

                            <h1>Users List</h1>

                            <p>List of Users With Info</p>

                        </div>               

                        <!--<div class="heading-elements">

                            <a href="#" class="btn btn-danger" id="page-like"><span class="app-spinner loading"></span> loading...</a>

                        </div>-->

                    </div>

                    <div class="app-heading-container app-heading-bordered bottom">

                        <ul class="breadcrumb">

                            <li><a href="#">Application</a></li>

                            <li><a href="#">Pages</a></li>

                            <li class="active">Users List</li>

                        </ul>

                    </div>

                    <!-- END PAGE HEADING -->

                    

                    <!-- START PAGE CONTAINER -->

                    <div class="container">
						<div class="row">
						<?php
						$split=0;
						foreach($users as $user){
							   
							if ($split%4==0){
								echo "</div> <div class='row'>";
							} 
							
							?>
							
                            <div class="col-md-3 col-xs-6" id="rowID<?php echo $user->user_id;?>">                                

                                <div class="block block-condensed padding-top-20">

                                    <div class="contact contact-bordered contact-single">

                                        <img src="<?php echo base_url();?>assets/images/users/user-60.jpg" alt="">

                                        <div class="contact-container">

                                            <a href="javascript:void(0);"><?php echo ucfirst($user->first_name.' '.$user->last_name);?></a>

                                            <span><?php echo (ucfirst($user->user_type) == 0)?"Customer":"Washer";?></span>
											<span>Pending Amounts : <?php echo (ucfirst($user->points) != 0)?$user->points:"0";?></span>

                                        </div> 

                                        <div class="contact-controls">

                                            <button class="btn btn-danger btn-clean btn-icon deleteuser" data-uid="<?php echo $user->user_id;?>"><span class="fa fa-trash-o"></span></button>

                                        </div>

                                        <div class="contact-controls contact-controls-dir-right">
                                            <button class="btn btn-success btn-clean btn-icon edituser" data-toggle="modal" data-target="#editUser" data-uid="<?php echo $user->user_id;?>" data-uname="<?php echo $user->first_name;?>"><span class="fa fa-edit"></span></button>
                                        </div>

                                    </div>

                                    <div class="list-group">                                        

                                        <div class="list-group-item"><span class="fa fa-map-marker"></span> <?php echo ($user->location != "") ? $user->location : "No Locatino/Address found!";?></div>

                                        <div class="list-group-item"><span class="fa fa-phone"></span><?php echo ($user->mobile_number != "") ? $user->mobile_number : "No phone number found!";?></div>

                                        <div class="list-group-item"><span class="fa fa-envelope"></span><?php echo $user->email;?></div>                                                                                                     
                                    </div>     

                                   

                                </div>                                

                            </div>

							<?php $split++;
						}?>
                    </div>

                    <!-- END PAGE CONTAINER -->

                    

                </div>

                <!-- END APP CONTENT -->

                                

            </div>

            <!-- END APP CONTAINER -->

<?php include'template/footer.php'; ?>		