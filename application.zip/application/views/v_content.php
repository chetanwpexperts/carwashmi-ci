<?php 
$this->load->view('template/header');
$this->load->view($content);
//$this->load->view('template/right');
$this->load->view('template/footer');
?>
