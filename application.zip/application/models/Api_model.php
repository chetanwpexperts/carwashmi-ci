<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
define ( "ERR_FAILURE",             -1 );
define ( "ERR_INVALID_EXPIRATION",  -2 );
define ( "ERR_INVALID_LENGTH",      -3 );
define ( "ERR_INVALID_MOD10",       -4 );
define ( "ERR_INVALID_PREFIX",      -5 );
define ( "ERR_NOT_NUMERIC",         -6 );
define ( "ERR_UNKNOWN",             -7 );

//Success Codes
define ( "CC_SUCCESS",  1 );
class Api_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
    }
	
	function register($data){ 
		$this->db->insert('users', $data);
		$rows =  $this->db->affected_rows();
		if($rows>0){
			$uid = $this->db->insert_id();		
			return $uid;
		}else{
			return FALSE;
		}
    }
	
	function getuser($key)
	{
		$this->db->where('email',$key);
		$query = $this->db->get('users');
		if ($query->num_rows() > 0){
			return true;
		}
	 
	}
	
	function getuserbyid($uid)
	{
		$this->db->where('user_id',$uid);
		$query = $this->db->get('users');
		if ($query->num_rows() > 0){
			return true;
		}
	 
	}

    function login($data)
	{
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('email',$data['email']);
		$this->db->where('password',md5($data['password']));
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 1) {
			$userdata =  $query->result_array();
			if($userdata[0]['email'] == $data['email'] && $userdata[0]['password'] == md5($data['password'])){
				return $userdata[0];
			}else{
				return '0';
			}
			
		} else {
			return false;
		}
	}
	
	function email_verify($email)
	{
		$this->db->select('is_email_verified');
		$this->db->from('users');
		$this->db->where('email',$email);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 1) {
			$userdata =  $query->result_array();
			return $userdata[0];
		} else {
			return false;
		}
	}
	
	function getusername($id){
		$this->db->select('*');
		$this->db->where('user_id', $id);  
		$query = $this->db->get('users');
		$arr = $query->result();
		$user = strstr($arr[0]->email, '@', true);	
		return $user;	
	}
	
	function updatetokan($random, $uid){
		$qry = "update users set tokan = '".$random."' where user_id = '".$uid."'";
		$query  = $this->db->query($qry);
		if($query){
			return true; 
		}else{
			return false;
		}
		die;
	}
	
	function checktokan($random, $uid){
		$qry = "update users set is_email_verified = 1 where user_id = '".$uid."' and tokan = '".$random."'";
		$query  = $this->db->query($qry);
		if($query){
			return true; 
		}else{
			return false;
		}
	}
	
	function update_password($data, $em){
		$this->db->trans_start();
		$this->db->set('password', $data);
		$this->db->where('email', $em);
		$this->db->update('users'); 
		$this->db->trans_complete();

       if ($this->db->trans_status() === FALSE){
			 return false;
        }else{ return true; }
	}
	
	function update_firstlogin_status($email){
		$qry = "";
		$this->db->select('*');
		$this->db->where('email', $email);  
		$query = $this->db->get('users');
		$arr = $query->result();
		$firstlogin = $arr[0]->firstlogin;
		if($firstlogin == 1){
			$data = array(
				'firstlogin' => 0
			);
			$this->db->trans_start();
			$this->db->where('email', $email);
			$this->db->update('users', $data); 
			 $this->db->trans_complete();
			if ($this->db->trans_status() === FALSE){
				return $this->db->_error_message();
			}else{ 
				return '1';
			}
		}else{
			return false;
		}
		die;
	}
	
	function update_forgot_firstlogin_status($email){
		$this->db->select('*');
		$this->db->where('email', $email);  
		$query = $this->db->get('users');
		$arr = $query->result();
		$firstlogin = $arr[0]->firstlogin;
		
		if($firstlogin == 0){
			$data = array(
				'firstlogin' => 1
			);
			$this->db->trans_start();
			$this->db->where('email', $email);
			$this->db->update('users', $data); 
			 $this->db->trans_complete();
			if ($this->db->trans_status() === FALSE){
				return $this->db->_error_message();
			}else{ 
				return '1';
			}
		}else{
			return false;
		}
		die;
	}
	
	function checkOldpassword($em){
		$this->db->select('*');
		$this->db->where('email', $em);  
		$query = $this->db->get('users');
		$arr = $query->result();
		return $arr[0]->password;
	}
	
	function forgotpassStatus($status, $email){
		$qry = "update users set forgot_status = '".$status."' where email = '".$email."'";
		$query  = $this->db->query($qry);
		if($query){
			return true; 
		}else{
			return false;
		}
	}
	
	function updateTempPass($hash,$mail){
		$qry = "update users set password = '".md5($hash)."' where email = '".$mail."'";
		$query  = $this->db->query($qry);
		if($query){
			return true; 
		}else{
			return false;
		}
	}
	
	function getprofile($uerid)
	{
		$qry = "SELECT u.* FROM users as u WHERE u.user_id = ".$uerid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false;
		}
	}
	
	function updateuser($data, $id){
        $this->db->trans_start();
        $this->db->where('user_id', $id);
        $this->db->update('users', $data);	
		$this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			return $this->db->_error_message();
        }else{ return true;}
	}
	
	function update_user_location($data, $email){
        $this->db->trans_start();
        $this->db->where('email', $email);
        $this->db->update('users', $data); 
		 $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			echo $this->db->_error_message();
        }else{ 
			echo '1';
		}
	}
	
	function update_location($data, $uid){
        $this->db->trans_start();
        $this->db->where('user_id', $uid);
        $this->db->update('users', $data); 
		 $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			echo $this->db->_error_message();
        }else{ 
			echo '1';
		}
	}
	
	function getAllwashers(){
		$qry = "SELECT u.* FROM users as u WHERE u.user_type = 1";
		$query = $this->db->query($qry);
		$arr = $query->result();
		return $arr;
	}
	
	function distance($lat1, $lon1, $lat2, $lon2) {
		$theta = $lon1 - $lon2;
		$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
		$dist = acos($dist);
		$dist = rad2deg($dist);
		$miles = $dist * 60 * 1.1515; 
		return $miles;
	}
	
	function checkprofileimage($user_id){
		$this->db->select('*');
		$this->db->where('user_id', $user_id);  
		$query = $this->db->get('user_temp');
		$arr = $query->result();
		if(count($arr) > 0){
			return $arr[0]->img_path;
		}else{
			return false;
		}
	}
	
	function update_profile_img($pic)
	{
		$p = $this->checkprofileimage($pic['user_id']);
		if(!$p){
			$this->db->insert('user_temp', $pic);
			return '1';
		}else{
			$this->db->where('user_id', $pic['user_id']);
			$this->db->update('user_temp', $pic);  
			return '2';
		}			
    }
	
	function request($requestData,$uid,$pointsu){
		$this->db->insert('client_request', $requestData);
		$rows =  $this->db->affected_rows();
		if($rows>0){
			$reuestid = $this->db->insert_id();	
			$qry = "SELECT * FROM users WHERE user_id = ".$uid; 
			$query = $this->db->query($qry);
			$row = $query->result(); 
			$points = $row[0]->points;
			$diductpoints = $points - $pointsu;
			$uq = "UPDATE users SET points = '".$diductpoints."' WHERE user_id = '".$uid."'";
			$this->db->query($uq);
						
			return $reuestid;
		}else{
			return FALSE;
		}
	}
	
	function add_response($responseData){
		$this->db->insert('washer_response', $responseData);
		$rows =  $this->db->affected_rows();
		if($rows>0){
			$uid = $this->db->insert_id();		
			return $uid;
		}else{
			return FALSE;
		}
	}
	
	function checkrequest($uid){
		$qry = "SELECT * FROM client_request WHERE user_id = ".$uid;
		$query = $this->db->query($qry);
		$row = $query->result();
		if(count($row) > 0){
			return $row[0];
		}
	}
	
	function checkwasher($uid){
		$qry = "SELECT * FROM washer_response WHERE user_id = ".$uid;
		$query = $this->db->query($qry);
		$row = $query->result();
		if(count($row) > 0){
			return $row[0];
		}
	}
	
	function checkwasherid($wid){
		$qry = "SELECT * FROM washer_response WHERE washer_response_id = ".$wid;
		$query = $this->db->query($qry);
		$row = $query->result();
		if(count($row) > 0){
			return $row[0];
		}
	}
	
	function getresponse(){
		$qry = "SELECT cr.*, wr.* FROM client_request as cr, washer_response as wr WHERE wr.client_request_id = cr.client_request_id";
		$query = $this->db->query($qry);
		$arr = $query->result();
		return $arr;
	}
	
	function getwashcount($uid){
		$data = $this->checkrequest($uid);
		if(count($data) > 0){
			$qry = "SELECT cr.*, wr.* FROM client_request as cr, washer_response as wr WHERE wr.user_id = cr.user_id AND cr.user_id = '".$uid."'";
			$query = $this->db->query($qry);
			$row = $query->result();
			return $row;
		}else{
			return false;
		}
	}
	
	function validatecard($number){
		global $type;
		$cardtype = array(
			"visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
			"mastercard" => "/^5[1-5][0-9]{14}$/",
			"amex"       => "/^3[47][0-9]{13}$/",
			"discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
		);

		if (preg_match($cardtype['visa'],$number)){
			$type= "visa";
			return 'visa';
		}else if (preg_match($cardtype['mastercard'],$number)){
			$type= "mastercard";
			return 'mastercard';
		}else if (preg_match($cardtype['amex'],$number)){
			$type= "amex";
			return 'amex';
		}else if (preg_match($cardtype['discover'],$number)){
			$type= "discover";
			return 'discover';
		}else{
			return 'unknown';
		} 
	}
	
	function is_valid_expiration ( $month, $year ){
		
		if ( ( !is_numeric ( $month ) ) || ( !is_numeric ( $year ) ) ){
			return ERR_INVALID_EXPIRATION;
		}

		
		if ( strlen ( $year ) == 4 ){
			$current_year = (integer) date ( 'Y' );
		}elseif ( strlen ( $year ) == 2 ){
			$current_year = (integer) date ( 'y' );
		}else{
			return ERR_INVALID_EXPIRATION;
		}

	
		$current_month = (integer) date ( 'm' );

		
		if ( ( $month < 1 ) || ( $month > 12 ) ){
			return ERR_INVALID_EXPIRATION;
		}

		
		if ( ( $year < $current_year ) || ( $year > ( $current_year + 10 ) ) ){
			return ERR_INVALID_EXPIRATION;
		}

	
		if ( ( $year == $current_year ) && ( $month < $current_month ) ){
			return ERR_INVALID_EXPIRATION;
		}

	
		return CC_SUCCESS;
	}
	
	function getwasherNotification($user_id){
		$data = $this->checkwasher($user_id);
		if(count($data)>0){	
			$qry = "SELECT cr.*, wr.* FROM client_request as cr, washer_response as wr WHERE cr.client_request_id = wr.client_request_id AND wr.user_id = '".$user_id."' AND cr.is_request_open = 0 AND wr.is_washer_accepted = 0"; 
			$query = $this->db->query($qry);
			$row = $query->result();
			return $row;
		}else{
			return false;
		}
	}
	
	function washerhistory($user_id){
		$data = $this->checkwasher($user_id);
		if(count($data)>0){	
			$qry = "SELECT cr.*, wr.* FROM client_request as cr, washer_response as wr WHERE cr.client_request_id = wr.client_request_id AND wr.user_id = '".$user_id."' AND cr.is_request_open = 1 OR (cr.is_request_open = 0 AND (wr.is_washer_accepted = 2 OR wr.is_washer_accepted = 3))"; 
			$query = $this->db->query($qry);
			$row = $query->result();
			return $row;
		}else{
			return false;
		}
	}
	
	function checkresponse($request_id){
		$qry = "SELECT cr.* FROM client_request as cr WHERE cr.client_request_id = '".$request_id."' AND cr.is_request_open = 0";  
		$query = $this->db->query($qry);
		$row = $query->result();
		return $row;
	}
	
	function updateWresponse($wid, $parm){
		$data = array(
			'is_washer_accepted' => $parm
		);
		$this->db->trans_start();
        $this->db->where('washer_response_id', $wid);
		$this->db->update('washer_response', $data); 
		$this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			return $this->db->_error_message();
        }else{ 
			return true;
		}
	}
	
	function updatePaymentResponse($rid, $status){
		$data = array(
			'is_payment_done' => $status
		);
		$this->db->trans_start();
        $this->db->where('client_request_id', $rid);
		$this->db->update('client_request', $data); 
		$this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			return $this->db->_error_message();
        }else{ 
			return true;
		}
	}
	
	function requestClose($reuestid, $parm){
		$data = array(
			'is_request_open' => $parm
		);
		$this->db->trans_start();
        $this->db->where('client_request_id', $reuestid);
		$this->db->update('client_request', $data); 
		$this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			return $this->db->_error_message();
        }else{ 
			return true;
		}
	}
	
	function allrequestclose($reuestid, $uid){
		$data = array(
			'is_washer_accepted' => 3
		);
		$this->db->trans_start();
        $this->db->where('client_request_id', $reuestid);
        $this->db->where('user_id != ', $uid); 
		$this->db->update('washer_response', $data); 
		$this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			return $this->db->_error_message();
        }else{ 
			return true;
		}
	}
	
	function getclientrequest($request_id){
		$qry = "SELECT u.*, cr.* FROM users as u, client_request as cr WHERE cr.client_request_id = '".$request_id."' AND cr.user_id = u.user_id"; 
		$query = $this->db->query($qry);
		$row = $query->result();
		if(count($row) > 0){
			return $row[0];
		}else{
			return false;
		}
	}
	
	function getallrequests($uid){
		$qry = "SELECT * FROM client_request WHERE user_id = ".$uid;
		$query = $this->db->query($qry);
		$row = $query->result();
		return $row;
	}
	
	function clientrequestdetail($request_id){
		$arrData = array();
		$qry = "SELECT * FROM washer_response WHERE client_request_id = '".$request_id."' AND is_washer_accepted = 1";
		$query = $this->db->query($qry);
		$row = $query->result();
		$washer_accepted_id = $row[0]->user_id;
		$arrData['washer_response_id'] = $washer_response_id = $row[0]->washer_response_id;
		$arrData['washerdetail'] = $this->checkwasherid($arrData['washer_response_id']);
		$qry1 = "SELECT * FROM users WHERE user_id = '".$washer_accepted_id."'";
		$query1 = $this->db->query($qry1);
		$row1 = $query1->result();
		$arrData['user'] = $row1[0];
		$qry2 = "SELECT cr.* FROM client_request as cr WHERE cr.client_request_id = '".$request_id."'"; 
		$query2 = $this->db->query($qry2);
		$row2 = $query2->result();
		$arrData['client_request'] = $row2[0];
		return $arrData;
	}
	
	function addorder($data){ 
		$this->db->insert('service_payment', $data);
		$rows =  $this->db->affected_rows();
		if($rows>0){
			$uid = $this->db->insert_id();		
			return $uid;
		}else{
			return FALSE;
		}
    }
	
	function addpoints($data,$uid,$points){ 
		$newpoints = "";
		if($data['transaction_status'] == 1){
			$qry1 = "SELECT points FROM users WHERE user_id = ".$uid;
			$queryy = $this->db->query($qry1);
			$roww = $queryy->result(); 
			if(count($roww[0]) > 0){
				$newpoints = ($roww[0]->points + $points);
				$uq = "UPDATE users SET points = '".$newpoints."' WHERE user_id = '".$uid."'";
				$this->db->query($uq);
			}
		}
			
		$this->db->insert('points_history', $data);
		$rows =  $this->db->affected_rows();
		if($rows>0){
			$id = $this->db->insert_id();
			return $id;
		}else{
			return false;
		}
    }
	
	function getpoints(){ 
		$qry = "SELECT * FROM points_history";
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false;
		}
    }
	
	function getpointsbyUid($uerid){ 
		$qry = "SELECT p.* FROM points_history as p WHERE p.user_id = ".$uerid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false;
		}
    }
	
	function addlocationhistory($data,$uid){
		$qry = "SELECT p.* FROM location_history as p WHERE p.user_id = ".$uid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			$this->db->trans_start();
			$this->db->where('user_id', $uid); 
			$this->db->update('location_history', $data); 
			$this->db->trans_complete();
			if ($this->db->trans_status() === FALSE){
				return $this->db->_error_message();
			}else{ 
				return true;
			}
		}else{
			$this->db->insert('location_history', $data);
			$rows =  $this->db->affected_rows();
			if($rows>0){
				$uid = $this->db->insert_id();		
				return true;
			}else{
				return FALSE;
			}
		}
		
		
	}
	
	function getlocationhistory($uerid){ 
		$qry = "SELECT * FROM location_history WHERE user_id = ".$uerid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false; 
		}
    }
	
	function updatedevicetokan($data, $uerid){
		$this->db->trans_start();
        $this->db->where('user_id', $uerid); 
		$this->db->update('users', $data); 
		$this->db->trans_complete();
        if ($this->db->trans_status() === FALSE){
			return $this->db->_error_message();
        }else{ 
			return true;
		}
	}
	
	function sdschecktokan($uid){
		$qry = "SELECT user_id, device_token FROM users WHERE user_id = ".$uid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		return $row[0]->device_token;
	}
	
	function sendnotification($token,$message){
		$path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
		
		// $fields = array(
			// 'to' => $id,
			// 'notification' => array('title' => 'Working Good', 'body' => 'That is all we want'),
			// 'data' => array('message' => $message)
		// );
		
		$fields = array (
				'registration_ids' => array (
						$token
				),
				'data' => array (
						"message" => $message
				)
		);
 
		$headers = array(
			'Authorization:key=AAAAQ0UQ8OA:APA91bFIv5LpTOyjisjDi5v-kZjkPaG414KOOzbfNfYxyu4VWl_implhePuHHQXNwxuhmhJXKVoaTv6rrNH-MLkO8pgharNRo9-M344E8_v80GrPwWhpWKVEuiMSGp8ETQ6sJYcDprJw',
			'Content-Type:application/json'
		);		
		$ch = curl_init();
 
		curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 ); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	
		$result = curl_exec($ch);
	   
		curl_close($ch);
		
		return $result;
	}
	
	function getclientID($requestID){
		$qry = "SELECT user_id FROM client_request WHERE client_request_id = ".$requestID;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		return $row[0]->user_id;
	}
	
	function getwasherID($responseID){
		$qry = "SELECT user_id FROM washer_response WHERE washer_response_id = ".$responseID;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		return $row[0]->user_id;
	}
	
	function getallwashersclosed(){
		$qry = "SELECT * FROM washer_response WHERE is_washer_accepted = 3";
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row;
		}
	}
	
	function cancel($requestID){
		$qry = "SELECT * FROM client_request WHERE client_request_id = ".$requestID; 
		$query = $this->db->query($qry);
		$row = $query->result(); 
		$uid = $row[0]->user_id;
		$points = $row[0]->points;
		$data = array('points' => $points);
		if($row[0]->is_request_open == 1){
			$uq = "UPDATE users SET points = '".$points."' WHERE user_id = '".$uid."'";
			$this->db->query($uq);
			$uq2 = "UPDATE client_request SET is_payment_done = 2 WHERE client_request_id = '".$requestID."'";
			$this->db->query($uq2); 
		}
	}
	
	function updateclientpaymentstatus($requestID,$param){
		$uq2 = "UPDATE client_request SET is_payment_done = ".$param." WHERE client_request_id = '".$requestID."'";
		$this->db->query($uq2); 
	}
	
	function jobstatus($rid,$uid){
		$uq = "UPDATE client_request SET is_job_completed = 1 WHERE client_request_id = '".$rid."'";
		$this->db->query($uq);
		$q = "SELECT points FROM client_request WHERE client_request_id = '".$rid."'";
		$qry = $this->db->query($q);
		$rows = $qry->result();
		$points = $rows[0]->points;
		$arr = array(
			'user_id' => $uid,
			'client_request_id' => $rid,
			'points' => $points,
			'transaction_type' => 2
		);
		$this->db->insert('user_accounts', $arr);
		$rows2 =  $this->db->affected_rows();
		if($rows2>0){
			$rowid = $this->db->insert_id();		
		}
		$qry1 = "SELECT points FROM users WHERE user_id = ".$uid;
		$query1 = $this->db->query($qry1);
		$row1 = $query1->result();
		$user_points = $row1[0]->points;
		$washerPoints = ($points + $user_points);
		$uqA = "UPDATE users SET points = '".$washerPoints."' WHERE user_id = '".$uid."'";
		$this->db->query($uqA);
		$t = "SELECT user_id, device_token FROM users where user_id = '".$uid."'";
		$tqry = $this->db->query($t);
		$trows = $tqry->result();
		$device_token = $rows[0]->device_token;
		$message = "Job successfully completed! ".$washerPoints." points has been added in your account.";
		$this->sendnotification($device_token,$message);
	}
	
	function useraccountdata($data,$request_id){
		$qry1 = "SELECT client_request_id, is_job_completed FROM client_request WHERE client_request_id = ".$request_id; 
		$queryy = $this->db->query($qry1);
		$rowss = $queryy->result();
		$qry = "SELECT ua.* FROM user_accounts as ua WHERE ua.client_request_id = ".$request_id;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row) > 0){
			if($rowss[0]->is_job_completed == 1){
				$this->db->trans_start();
				$this->db->where('client_request_id', $request_id); 
				$this->db->update('user_accounts', $data); 
				$this->db->trans_complete();
				if ($this->db->trans_status() === FALSE){
					return $this->db->_error_message();
				}else{ 
					return true;
				}
			}
		}else{
			$this->db->insert('user_accounts', $data);
			$rows =  $this->db->affected_rows();
			if($rows>0){
				$uid = $this->db->insert_id();		
				return true;
			}else{
				return FALSE;
			}
		}
		
		
	}
	
	function getuserData($uerid)
	{
		$qry = "SELECT u.*,ua.*, (select sum(points) from user_accounts where user_id = '".$uerid."') as total_points FROM users as u, user_accounts as ua WHERE ua.user_id = u.user_id AND u.user_id = ".$uerid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false;
		}
	}
	
	function getDatawashmi($uerid){
		$rData = array();
		$qry = "SELECT * FROM user_accounts WHERE user_id = ".$uerid." AND transaction_type = 2"; 
		$query = $this->db->query($qry);
		$rows = $query->result();
		if(count($rows[0]) > 0){
			$rData['useraccounts'] = $rows[0];
			foreach($rows as $r){
				$requestID = $rows[0]->client_request_id;
				$qry1 = "SELECT * FROM client_request WHERE client_request_id = ".$requestID; 
				$query1 = $this->db->query($qry1);
				$row = $query1->result();
				$rData['requestdata'] = $row[0];
			}
			return $rData;
		}else{ 
			return false; 
		}
	}
	
	function getuserCardDetails($uerid)
	{
		$qry = "SELECT u.*,ps.* FROM users as u, payment_settigns as ps WHERE ps.user_id = u.user_id AND u.user_id = ".$uerid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false;
		}
	}
	
	function saveauthorization($data){
		$userdata = $this->getuserbyid($uerid);
		if($userdata == true){
			$this->db->trans_start();
			$this->db->where('user_id', $uerid); 
			$this->db->update('authorized_data', $data); 
			$this->db->trans_complete();
			if ($this->db->trans_status() === FALSE){
				return $this->db->_error_message();
			}else{ 
				return true;
			}
		}else{
			$this->db->insert('authorized_data', $data);
			$rows =  $this->db->affected_rows();
			if($rows>0){
				$uid = $this->db->insert_id();		
				return true;
			}else{
				return FALSE;
			}
		}
	}
	
	function getusertokens($uerid){
		$qry = "SELECT u.* FROM authorized_data as u.user_id = ".$uerid;
		$query = $this->db->query($qry);
		$row = $query->result(); 
		if(count($row[0]) > 0){
			return $row[0];
		}else{
			return false;
		}
	}
		
}
?>