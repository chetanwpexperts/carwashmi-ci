<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model
{	function __construct()    {
		parent::__construct(); 
		$this->load->library('session');
		$this->load->database();    
	}
	function users(){
		$this->db->select("*");
		$this->db->from('users');
		$query = $this->db->get();
		return $query->result();
		return $arr;
	}
	function profile(){
		$this->db->select("*");
		$this->db->from('account');
		$this->db->where('usertype', "admin");
		$query = $this->db->get();
		return $query->result();
		return $arr;
	} 
	function edit($uid){
		$qry = "SELECT * FROM users WHERE user_id = '".$uid."' AND user_type != 'admin'";
		$sql = $this->db->query($qry);
		$row = $sql->row_array();
		if(count($row) > 0){
			return $row;
		}else{
			return '0';
		}
	} 
	function updateuser($data,$id){
		// print_r($data);
		$this->db->where('user_id', $id);
		$true = $this->db->update('users', $data); 
		if($true){
			return true;
		}else{
			return false;
		}
	} 
	function deleteusr($id){ 
		$res = $this->db->delete('users', array('user_id' => $id)); 
		if($res){
			return true;
		}else{
			return false;
		}
	} 
}
?>