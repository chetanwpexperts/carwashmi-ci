<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Service_model extends CI_Model
{	function __construct()    {
		parent::__construct(); 
		$this->load->library('session');
		$this->load->database();    
	}
	function services(){
		$this->db->select("*");
		$this->db->from('services');
		$query = $this->db->get();
		return $query->result();
		return $arr;
	}
	
	function edit($sid){
		$qry = "SELECT * FROM services WHERE id = '".$sid."'";
		$sql = $this->db->query($qry);
		$row = $sql->row_array();
		if(count($row) > 0){
			switch($row['service_type']){
				case "0":
					$service_name = "Elite";
					break;
				case "1":
					$service_name = "Standard";
					break;
				case "2":
					$service_name = "Premium";
					break;
			}
			return $service_name;
		}else{
			return '0';
		}
	} 
	function update($data,$id){
		// print_r($data);
		$this->db->where('id', $id);
		$true = $this->db->update('services', $data); 
		if($true){
			return true;
		}else{
			return false;
		}
	} 
	function deletes($id){ 
		$res = $this->db->delete('services', array('id' => $id)); 
		if($res){
			return true;
		}else{
			return false;
		}
	}
}